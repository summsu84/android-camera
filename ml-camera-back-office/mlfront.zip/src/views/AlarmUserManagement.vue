<template>
    <div class="wrapper">
        알람 연락처 관리
    </div>
</template>
<script>
export default {
  name: 'UserManagement',
};
</script>

<style>

</style>

